// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Download",
      "filePrefix": "timing-validation",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "Timing validation",
    "description": "",
    "repository": "https:\u002F\u002Fgithub.com\u002FFelixHenninger\u002Flab.js\u002Ftree\u002Fmaster\u002Fexamples",
    "contributors": "Felix Henninger (mailbox@felixhenninger.com) [https:\u002F\u002Ffelixhenninger.com]"
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Screen",
      "parameters": {},
      "responses": {
        "keypress": "continue"
      },
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
// Setup study from window URL parameters, if available
const urlParams = new URLSearchParams(window.location.search)
this.parameters._collect_response = urlParams.get('response') === 'true'

// Generate additional rendering load, if desired
const squares = 1

// Setup stimulus generation function
window.makeStimuli = function(
  collect_response=this.parameters._collect_response, 
  trial_length=1000
) {

  console.log('Building benchmark study with ...')
  console.log('collect_response', collect_response)
  console.log('trial_length', trial_length)

  // ---------------------------------------------------------------------------
  const make_square = (fill='#ffffff') => ({
    "type": "rect",
    "left": 0, "top": -150,
    "width": "300", "height": "300",
    "fill": fill
  })

  const content_black = new Array(squares)
    .fill(0)
    .map(
      () => make_square('#000000')
    )

  const content_white = new Array(squares)
    .fill(0)
    .map(
      () => make_square('#ffffff')
    )

  const make_screen = (title, content, timeout, responses={}, timeline=[]) =>
    new lab.canvas.Screen({
      title: title,
      content: content,
      timeout: timeout,
      responses: responses,
      timeline: timeline,
      //debug: true,
    })

  var trial_content = []

  // Assemble trial
  trial_content.push(
    make_screen(
      'buffer',
      [ make_square('#000000') ],
      10000
    )
  )

  Array(trial_length).fill(0)
    .forEach((_, i) => {
      const title   = i % 2 == 0 ? 'black' : 'white'
      const content = i % 2 == 0 ? content_black : content_white
      const l_screentime = i % 2 == 0 
        ? 300
        : (collect_response ? undefined : 200)
      const l_responses = collect_response && i % 2 !== 0 
        ? { 'keydown': 'response' }
        : {}
      const l_timeline = collect_response || i % 2 == 0 
        ? []
        : [
            {
              "type": "oscillator",
              "start": 0,
              "stop": 200,
              "priority": 0,
              "payload": {
                "gain": 1,
                "pan": 0,
                "rampUp": 0,
                "rampDown": 0
              }
            }
          ]

      trial_content.push(
        make_screen(
          title,
          content,
          l_screentime,
          l_responses,
          l_timeline
        )
      )
    })

    trial_content.push(
      make_screen(
        'buffer',
        [ make_square('#000000') ],
        5000
      )
    )

  return new lab.flow.Sequence({
    title: 'sequence',
    content: trial_content
  })
}
},
        "after:end": function anonymous(
) {
// Substitute URL parameters if there is no form content
this.state.collect_response = this.state._collect_response || false
}
      },
      "title": "Settings",
      "content": "\u003Cmain class=\"content-vertical-center content-horizontal-center\"\u003E\n  \u003Cdiv\u003E\n    Please press a key to begin\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E",
      "files": {}
    },
    {
      "type": "lab.canvas.Frame",
      "context": "\u003C!-- The loop logic is filled by script --\u003E\n\u003Ccanvas \u002F\u003E",
      "contextSelector": "canvas",
      "parameters": {},
      "responses": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
// Setup file download name
this.parent.plugins.plugins.forEach((p, i) => {
  if (p instanceof lab.plugins.Download) {
    const ua = new UAParser()
    p.filePrefix = 
      `labjs-validation-${ ua.getBrowser().name }-` +
      `${ ua.getBrowser().version }--` +
      `${ ua.getOS().name }-${ ua.getOS().version }--` +
      (this.state.collect_response ? 'response' : 'presentation')
  }
})

// Make stimuli
this.options.content = window.makeStimuli(
  Boolean(this.state.collect_response)
)
}
      },
      "title": "Validation loop",
      "tardy": true,
      "files": {}
    }
  ]
})

// Let's go!
study.run()